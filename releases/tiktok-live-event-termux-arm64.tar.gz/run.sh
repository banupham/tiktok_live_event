#!/data/data/com.termux/files/usr/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if ! command -v node >/dev/null 2>&1; then
  echo '[THIEU NODE] Gói này không cần npm install, nhưng Termux phải có runtime node.' >&2
  echo 'Cần lệnh node có sẵn trong Termux.' >&2
  exit 10
fi
if ! command -v python >/dev/null 2>&1; then
  echo '[THIEU PYTHON] Gói này không cần pip install, nhưng Termux phải có runtime python.' >&2
  echo 'Cần lệnh python có sẵn trong Termux.' >&2
  exit 11
fi
python - <<'PY'
import sys
if sys.version_info < (3, 14):
    raise SystemExit('Cần Python Termux 3.14+ để dùng native pydantic-core đã đóng gói.')
PY

if [ "$#" -lt 1 ]; then
  echo 'Cach dung: ./run.sh ten_tiktok [api_port]'
  exit 1
fi

USERNAME=$1
if [ "${2:-}" != "" ]; then export API_PORT=$2; fi
: "${API_PORT:=8787}"
export API_PORT COLLECTOR_MODE=direct PYTHON_BIN=python
export PYTHONPATH="$ROOT/vendor${PYTHONPATH:+:$PYTHONPATH}"
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python
exec node "$ROOT/app/a.mjs" "$USERNAME"
