#!/data/data/com.termux/files/usr/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if ! command -v node >/dev/null 2>&1; then
  echo '[THIEU NODE] Can runtime node cua Termux; khong can npm install.' >&2
  exit 10
fi
if ! command -v python >/dev/null 2>&1; then
  echo '[THIEU PYTHON] Can runtime python cua Termux; khong can pip install.' >&2
  exit 11
fi
python - <<'PY'
import sys
if sys.version_info < (3, 14):
    raise SystemExit('Can Python Termux 3.14+ cho native pydantic-core da dong goi.')
PY
if [ "$#" -lt 1 ]; then
  echo 'Cach dung: ./run.sh ten_tiktok [api_port]'
  exit 1
fi
USERNAME=$1
if [ "${2:-}" != "" ]; then export API_PORT=$2; fi
: "${API_PORT:=8787}"
export API_PORT COLLECTOR_MODE=direct PYTHON_BIN=python
export PYTHONPATH="$ROOT/vendor${PYTHONPATH:+:$PYTHONPATH}"
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python
exec node "$ROOT/app/a.mjs" "$USERNAME"
