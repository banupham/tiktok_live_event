TERMUX ARM64 - KHONG CAN npm install / pip install
==================================================
Co event avatar: avatar_thumb duoc tai mot lan/user vao thu muc temp cua collector.
Event avatar gom avatarUrl + avatarPath; cung avatar khong lap theo comment/join/like/gift.
Thu vien Python da vendor san, gom pydantic-core native Android ARM64.
Yeu cau nen: Termux co san node va python (Python 3.14 target).
Chay: ./run.sh ten_tiktok [api_port]
