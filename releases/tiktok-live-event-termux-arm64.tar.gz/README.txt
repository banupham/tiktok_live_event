TERMUX ARM64 - KHONG CAN npm install / pip install
==================================================
Da dong goi san TikTokLive va cac Python dependencies, gom ca pydantic-core native cho Android ARM64.

Yeu cau nen: Termux co san lenh node va python (Python 3.14 target).
Khong dung file Linux ARM64 cho Termux vi Android dung Bionic.

Chay:
  ./run.sh ten_tiktok
  ./run.sh ten_tiktok 8788
