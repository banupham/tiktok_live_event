TERMUX ARM64 - KHONG CAN npm install / pip install
==================================================
Co event avatar: avatar_thumb duoc tai mot lan/user vao thu muc temp cua collector.
API mac dinh bind 0.0.0.0:8787 de thiet bi khac trong LAN truy cap.
Muon chi local: API_HOST=127.0.0.1 ./run.sh ten_tiktok
Thu vien Python da vendor san, gom pydantic-core native Android ARM64.
Yeu cau nen: Termux co san node va python (Python 3.14 target).
Chay: ./run.sh ten_tiktok [api_port]
